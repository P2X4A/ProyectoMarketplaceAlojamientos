//#region node_modules/@angular/common/locales/es-CO.js
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.dev/license
*/
var u = void 0;
function plural(val) {
	const n = val, i = Math.floor(Math.abs(val)), v = val.toString().replace(/^[^.]*\.?/, "").length, e = parseInt(val.toString().replace(/^[^e]*(e([-+]?\d+))?/, "$2")) || 0;
	if (n === 1) return 1;
	if (e === 0 && !(i === 0) && i % 1e6 === 0 && v === 0 || !(e >= 0 && e <= 5)) return 4;
	return 5;
}
var es_CO_default = [
	"es-CO",
	[
		["a. m.", "p. m."],
		u,
		["a.\xA0m.", "p.\xA0m."]
	],
	u,
	[
		[
			"D",
			"L",
			"M",
			"m",
			"J",
			"V",
			"S"
		],
		[
			"dom",
			"lun",
			"mar",
			"mié",
			"jue",
			"vie",
			"sáb"
		],
		[
			"domingo",
			"lunes",
			"martes",
			"miércoles",
			"jueves",
			"viernes",
			"sábado"
		],
		[
			"DO",
			"LU",
			"MA",
			"MI",
			"JU",
			"VI",
			"SA"
		]
	],
	[
		[
			"d",
			"l",
			"m",
			"m",
			"j",
			"v",
			"s"
		],
		[
			"dom",
			"lun",
			"mar",
			"mié",
			"jue",
			"vie",
			"sáb"
		],
		[
			"domingo",
			"lunes",
			"martes",
			"miércoles",
			"jueves",
			"viernes",
			"sábado"
		],
		[
			"DO",
			"LU",
			"MA",
			"MI",
			"JU",
			"VI",
			"SA"
		]
	],
	[
		[
			"E",
			"F",
			"M",
			"A",
			"M",
			"J",
			"J",
			"A",
			"S",
			"O",
			"N",
			"D"
		],
		[
			"ene",
			"feb",
			"mar",
			"abr",
			"may",
			"jun",
			"jul",
			"ago",
			"sept",
			"oct",
			"nov",
			"dic"
		],
		[
			"enero",
			"febrero",
			"marzo",
			"abril",
			"mayo",
			"junio",
			"julio",
			"agosto",
			"septiembre",
			"octubre",
			"noviembre",
			"diciembre"
		]
	],
	[
		[
			"E",
			"F",
			"M",
			"A",
			"M",
			"J",
			"J",
			"A",
			"S",
			"O",
			"N",
			"D"
		],
		[
			"ene.",
			"feb.",
			"mar.",
			"abr.",
			"may.",
			"jun.",
			"jul.",
			"ago.",
			"sept.",
			"oct.",
			"nov.",
			"dic."
		],
		[
			"enero",
			"febrero",
			"marzo",
			"abril",
			"mayo",
			"junio",
			"julio",
			"agosto",
			"septiembre",
			"octubre",
			"noviembre",
			"diciembre"
		]
	],
	[
		["a.C.", "d.C."],
		u,
		["antes de Cristo", "después de Cristo"]
	],
	0,
	[6, 0],
	[
		"d/MM/yy",
		"d/MM/y",
		"d 'de' MMMM 'de' y",
		"EEEE, d 'de' MMMM 'de' y"
	],
	[
		"h:mm a",
		"h:mm:ss a",
		"h:mm:ss a z",
		"h:mm:ss a zzzz"
	],
	[
		"{1}, {0}",
		u,
		u,
		u
	],
	[
		",",
		".",
		";",
		"%",
		"+",
		"-",
		"E",
		"×",
		"‰",
		"∞",
		"NaN",
		":"
	],
	[
		"#,##0.###",
		"#,##0%",
		"¤\xA0#,##0.00",
		"#E0"
	],
	"COP",
	"$",
	"peso colombiano",
	{
		"AUD": [u, "$"],
		"BRL": [u, "R$"],
		"BYN": [u, "р."],
		"CAD": [u, "$"],
		"CNY": [u, "¥"],
		"COP": ["$"],
		"ESP": ["₧"],
		"EUR": [u, "€"],
		"FKP": [u, "FK£"],
		"GBP": [u, "£"],
		"HKD": [u, "$"],
		"ILS": [u, "₪"],
		"INR": [u, "₹"],
		"JPY": [u, "¥"],
		"KRW": [u, "₩"],
		"MXN": [u, "$"],
		"NZD": [u, "$"],
		"PHP": [u, "₱"],
		"RON": [u, "L"],
		"SSP": [u, "SD£"],
		"SYP": [u, "S£"],
		"TWD": [u, "NT$"],
		"USD": ["US$", "$"],
		"VEF": [u, "BsF"],
		"VND": [u, "₫"],
		"XAF": [],
		"XCD": [u, "$"],
		"XOF": []
	},
	"ltr",
	plural
];
//#endregion
export { es_CO_default as default };
